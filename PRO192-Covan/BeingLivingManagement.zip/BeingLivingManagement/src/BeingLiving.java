
public abstract class BeingLiving {

    private String name;

    public BeingLiving() {
        name = "things";
    }

    public BeingLiving(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    //cac ham con khong duoc override ham nay
    public final void useWater() {
        System.out.println("use Sweet Water");
    }

    public abstract void grow();

}
