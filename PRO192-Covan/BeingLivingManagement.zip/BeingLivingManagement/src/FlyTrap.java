
public class FlyTrap extends Plant implements Food {

    @Override
    public void eatFly() {
        System.out.println("mo nap");
        System.out.println("ruoi bay vao");
        System.out.println("day nap lai");
    }

}
