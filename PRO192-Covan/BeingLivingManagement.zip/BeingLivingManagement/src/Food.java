
public interface Food {

    final int quantityOfFly = 10;// bien nay la constant

    void eatFly(); // public abstract void eatFly();
}
