
import java.util.Scanner;

public class Tester {

    public static void main(String[] args) {
        int choice = 0;
        BeingLiving obj = null;
        // BeingLiving obj = new BeingLiving(); error
        // PriceTable tmp = new PriceTable(); error
        //PriceTable tmp = new Orchid(); it's ok
        //Cach thuong dung 
//        PriceTable tmp = new PriceTable() {
//            @Override
//            public void updatePrice() {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//            }
//        }
        do {
            System.out.println("1.Create a beingLiving");
            System.out.println("2. Call use water");
            System.out.println("3. call grow");
            System.out.println("4. call updatePrice");
            System.out.println("5. call eatFly");
            System.out.println("enter a choice:");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("1. create a orchid");
                    System.out.println("2. create a flytrap");
                    System.out.println("3. create a komodo");
                    System.out.println("enter a choice:");
                    int choice2 = 0;
                    sc = new Scanner(System.in);
                    choice2 = sc.nextInt();
                    switch (choice2) {
                        case 1:
                            obj = new Orchid(100, "catlleya");
                            break;
                        case 2:
                            obj = new FlyTrap();
                            break;
                        case 3:
                            obj = new Komodo();
                            break;
                    }
                    break;
                case 2:
                    if (obj != null) {
                        obj.useWater();
                    }
                    break;
                case 3:
                    if (obj != null) {
                        obj.grow();
                    }
                    break;
                case 4:
                    if (obj != null) {
                        if (obj instanceof PriceTable) {
                            PriceTable pt = (PriceTable) obj;
                            pt.updatePrice();

                        }

                    }
                    break;
                case 5:
                    if (obj != null) {
                        if (obj instanceof Food) {
                            Food f = (Food) obj;
                            f.eatFly();

                        }

                    }
                    break;
            }
        } while (choice < 6);
    }
}
