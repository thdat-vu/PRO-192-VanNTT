
public class Komodo extends Animal implements Food, PriceTable {
    private int price;

    public Komodo() {
        super();
        price = 10000;
    }

    public Komodo(String name) {
        super(name);
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    @Override
    public void eatFly() {
        System.out.println("le luoi");
        System.out.println("ruoi bay vao");
        System.out.println("ngam mieng lai");
    }

    @Override
    public void updatePrice() {
        price = price * 10;
    }
    
}
