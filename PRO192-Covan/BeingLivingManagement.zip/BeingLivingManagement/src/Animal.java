
public class Animal extends BeingLiving {

    public Animal() {
        super();
    }

    public Animal(String name) {
        super(name);
    }

    @Override
    public void grow() {
        System.out.println("by food");
    }

    public void run() {
        System.out.println("run by feet");
    }
}
