
public interface PriceTable {
    void updatePrice();
}
